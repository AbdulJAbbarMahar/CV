import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment } from '@react-three/drei';
import * as THREE from 'three';
import { useReducedMotion } from '@/hooks/useReducedMotion';

/* ═══════════════════════════════════════════════════════════════════════════
   ThreeScene — Optimized Hero Background
   Taste Skill: MOTION_INTENSITY 6 — scroll-reactive, performant
   Emil Design Eng: perceived performance via smooth interpolation
   ═══════════════════════════════════════════════════════════════════════════ */

const GOLD = new THREE.Color('#d4a843');
const GOLD_DIM = new THREE.Color('#b88a32');
const AMBIENT_COL = new THREE.Color('#1a1a1e');

/* ── Floating Particles ─────────────────────────────────────────────────── */
function Particles({ count = 400 }: { count?: number }) {
  const meshRef = useRef<THREE.Points>(null);
  const reducedMotion = useReducedMotion();

  const [positions, colors] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 10 - 4;

      const isGold = Math.random() < 0.25;
      col[i * 3] = isGold ? 0.831 : 0.35;
      col[i * 3 + 1] = isGold ? 0.659 : 0.35;
      col[i * 3 + 2] = isGold ? 0.263 : 0.45;
    }
    return [pos, col];
  }, [count]);

  const speeds = useMemo(() => {
    return Array.from({ length: count }, () => 0.2 + Math.random() * 0.4);
  }, [count]);

  useFrame(({ clock }) => {
    if (!meshRef.current || reducedMotion) return;
    const t = clock.getElapsedTime();
    meshRef.current.rotation.y = t * 0.012;
    meshRef.current.rotation.x = Math.sin(t * 0.04) * 0.06;

    // Subtle particle breathing
    const posAttr = meshRef.current.geometry.attributes.position;
    for (let i = 0; i < count; i += 10) {
      const idx = i * 3 + 1;
      posAttr.array[idx] += Math.sin(t * speeds[i] + i) * 0.0003;
    }
    posAttr.needsUpdate = true;
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
          count={count}
        />
        <bufferAttribute
          attach="attributes-color"
          args={[colors, 3]}
          count={count}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.04}
        vertexColors
        transparent
        opacity={0.7}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

/* ── Glass Orbs ─────────────────────────────────────────────────────────── */
function GlassOrb({
  position,
  scale = 1,
  speed = 0.3,
}: {
  position: [number, number, number];
  scale?: number;
  speed?: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const reducedMotion = useReducedMotion();

  useFrame(({ clock }) => {
    if (!meshRef.current || reducedMotion) return;
    const t = clock.getElapsedTime();
    meshRef.current.position.y = position[1] + Math.sin(t * speed) * 0.25;
    meshRef.current.rotation.x = t * 0.08;
    meshRef.current.rotation.z = t * 0.05;
  });

  return (
    <mesh ref={meshRef} position={position} scale={scale}>
      <sphereGeometry args={[1, 32, 32]} />
      <meshPhysicalMaterial
        color={GOLD}
        transparent
        opacity={0.12}
        roughness={0.05}
        metalness={0.15}
        transmission={0.85}
        thickness={0.6}
        ior={1.45}
        clearcoat={1}
        clearcoatRoughness={0.08}
        side={THREE.DoubleSide}
        depthWrite={false}
      />
    </mesh>
  );
}

/* ── Gold Ring ──────────────────────────────────────────────────────────── */
function GoldRing() {
  const meshRef = useRef<THREE.Mesh>(null);
  const reducedMotion = useReducedMotion();

  useFrame(() => {
    if (!meshRef.current || reducedMotion) return;
    meshRef.current.rotation.x += 0.002;
    meshRef.current.rotation.y += 0.001;
  });

  return (
    <mesh ref={meshRef} position={[3, -1, -3]} rotation={[0.5, 0.3, 0]}>
      <torusGeometry args={[2, 0.018, 16, 100]} />
      <meshStandardMaterial
        color={GOLD}
        emissive={GOLD}
        emissiveIntensity={0.25}
        transparent
        opacity={0.4}
      />
    </mesh>
  );
}

/* ── Star Field ─────────────────────────────────────────────────────────── */
function StarField({ count = 800 }: { count?: number }) {
  const meshRef = useRef<THREE.Points>(null);

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 40 + Math.random() * 20;
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi);
    }
    return pos;
  }, [count]);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.y = clock.getElapsedTime() * 0.003;
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
          count={count}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color="#ffffff"
        transparent
        opacity={0.4}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}

/* ── Mouse-reactive Camera Rig ──────────────────────────────────────────── */
function CameraRig() {
  const reducedMotion = useReducedMotion();

  useFrame(({ camera, pointer }) => {
    if (reducedMotion) return;
    const targetX = pointer.x * 0.2;
    const targetY = pointer.y * 0.12;
    camera.position.x += (targetX - camera.position.x) * 0.03;
    camera.position.y += (targetY - camera.position.y) * 0.03;
    camera.lookAt(0, 0, 0);
  });

  return null;
}

/* ── Main Scene ─────────────────────────────────────────────────────────── */
export default function ThreeScene() {
  const reducedMotion = useReducedMotion();

  return (
    <div
      className="absolute inset-0 z-0"
      style={{ background: 'transparent' }}
      aria-hidden="true"
    >
      <Canvas
        camera={{ position: [0, 0, 5], fov: 60, near: 0.1, far: 100 }}
        dpr={[1, Math.min(window.devicePixelRatio, 1.5)]}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: 'high-performance',
        }}
        style={{ background: 'transparent' }}
      >
        {/* Lighting */}
        <ambientLight intensity={0.25} color={AMBIENT_COL} />
        <pointLight position={[5, 5, 5]} intensity={1.2} color={GOLD} distance={20} />
        <pointLight position={[-5, -3, -5]} intensity={0.4} color={GOLD_DIM} distance={20} />
        <spotLight
          position={[0, 8, 2]}
          intensity={0.6}
          color={GOLD}
          angle={0.4}
          penumbra={1}
        />

        {/* Scene Elements */}
        <Particles count={reducedMotion ? 100 : 400} />
        <StarField count={reducedMotion ? 200 : 800} />
        <GlassOrb position={[-3.5, 1.2, -2]} scale={1} speed={0.25} />
        <GlassOrb position={[3.8, -0.8, -3]} scale={0.65} speed={0.35} />
        <GlassOrb position={[0, -2.5, -1.5]} scale={0.4} speed={0.4} />
        <GoldRing />
        <CameraRig />

        {/* Subtle environment */}
        <Environment preset="night" environmentIntensity={0.15} />
      </Canvas>
    </div>
  );
}
