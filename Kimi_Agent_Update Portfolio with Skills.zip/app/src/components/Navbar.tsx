import { useState, useEffect, useCallback } from 'react';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';

/* ═══════════════════════════════════════════════════════════════════════════
   Navbar — Fixed Navigation
   Impeccable: proper heading hierarchy, touch targets 44px+
   Emil Design Eng: sub-300ms transitions, custom easing
   ═══════════════════════════════════════════════════════════════════════════ */

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Projects', href: '#projects' },
  { label: 'Skills', href: '#skills' },
  { label: 'Experience', href: '#experience' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMobile = useCallback(() => {
    setMobileOpen(false);
    document.body.style.overflow = '';
  }, []);

  const openMobile = useCallback(() => {
    setMobileOpen(true);
    document.body.style.overflow = 'hidden';
  }, []);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeMobile();
    };
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }, [closeMobile]);

  return (
    <>
      <nav
        role="navigation"
        aria-label="Main navigation"
        className={cn(
          'fixed top-0 left-0 right-0 z-[800] flex items-center justify-between',
          'transition-[padding,background] duration-300',
          scrolled
            ? 'glass-surface py-3 px-6 md:px-12'
            : 'bg-transparent py-5 px-6 md:px-12'
        )}
        style={{
          transitionTimingFunction: 'var(--ease-out-expo)',
        }}
      >
        {/* Logo */}
        <a
          href="#"
          className="font-display text-lg font-extrabold tracking-tight text-[var(--text-primary)] no-underline select-none"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          dm<em className="text-[var(--gold)] not-italic">.</em>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          <ul className="flex gap-8 list-none m-0 p-0" role="menubar">
            {NAV_LINKS.map((link) => (
              <li key={link.href} role="none">
                <a
                  href={link.href}
                  role="menuitem"
                  className="font-mono text-[0.74rem] font-medium tracking-[0.07em] uppercase text-[var(--text-muted)] no-underline transition-colors duration-150 hover:text-[var(--text-primary)]"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    transitionTimingFunction: 'var(--ease-out-expo)',
                  }}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="btn-primary"
            style={{
              padding: '0.55rem 1.35rem',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.74rem',
              letterSpacing: '0.08em',
              textTransform: 'uppercase' as const,
              fontWeight: 600,
            }}
          >
            Let's Talk
            <span className="shimmer" aria-hidden="true" />
          </a>
        </div>

        {/* Hamburger — Touch target 44px (UI/UX Pro Max) */}
        <button
          id="hamburger"
          aria-label="Toggle menu"
          aria-expanded={mobileOpen}
          aria-controls="mobile-menu"
          onClick={() => (mobileOpen ? closeMobile() : openMobile())}
          className="md:hidden flex flex-col items-center justify-center w-10 h-10 rounded-lg border border-[var(--border)] bg-transparent transition-colors duration-150 hover:border-[var(--gold-muted)]"
          style={{
            minWidth: '44px',
            minHeight: '44px',
            transitionTimingFunction: 'var(--ease-out-expo)',
          }}
        >
          {mobileOpen ? (
            <X size={18} className="text-[var(--text-secondary)]" />
          ) : (
            <Menu size={18} className="text-[var(--text-secondary)]" />
          )}
        </button>
      </nav>

      {/* Mobile Menu */}
      <div
        id="mobile-menu"
        role="dialog"
        aria-modal="true"
        aria-label="Mobile navigation"
        className={cn(
          'fixed inset-0 z-[799] flex flex-col items-center justify-center gap-8',
          'bg-[var(--base)]/97 backdrop-blur-2xl',
          'transition-opacity duration-300',
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
        style={{ transitionTimingFunction: 'var(--ease-out-expo)' }}
      >
        {NAV_LINKS.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={closeMobile}
            className="font-display text-2xl font-bold text-[var(--text-secondary)] no-underline transition-colors duration-150 hover:text-[var(--gold)]"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            {link.label}
          </a>
        ))}
        <a
          href="#contact"
          onClick={closeMobile}
          className="btn-primary mt-2"
          style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700 }}
        >
          Let's Talk
        </a>
      </div>
    </>
  );
}
