import { useState, useEffect, useRef, type RefObject } from 'react';

/**
 * useInView — IntersectionObserver hook for scroll reveals
 * Optimized with once:true to prevent re-triggering
 */
export function useInView(
  ref: RefObject<Element | null>,
  options?: IntersectionObserverInit & { once?: boolean }
): boolean {
  const [isInView, setIsInView] = useState(false);
  const hasTriggered = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const { once = true, ...observerOptions } = options || {};

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (once) {
            hasTriggered.current = true;
            observer.unobserve(el);
          }
        } else if (!once) {
          setIsInView(false);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -40px 0px',
        ...observerOptions,
      }
    );

    if (!hasTriggered.current) {
      observer.observe(el);
    }

    return () => observer.disconnect();
  }, [ref, options?.root, options?.rootMargin, options?.threshold]);

  return isInView;
}
