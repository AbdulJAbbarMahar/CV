import { useRef } from 'react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   Skills — Two-column layout with grouped chips
   Taste Skill: DESIGN_VARIANCE 8 — asymmetric sidebar layout
   UI/UX Pro Max: interactive chips, proper labels
   ═══════════════════════════════════════════════════════════════════════════ */

const SKILL_GROUPS = [
  {
    label: 'Web',
    skills: ['WordPress', 'HTML5', 'CSS3', 'JavaScript', 'WooCommerce', 'Responsive Design'],
  },
  {
    label: 'ServiceNow',
    skills: ['ITSM', 'HRSD', 'ITOM', 'CMDB', 'Flow Designer', 'GlideRecord', 'GlideAjax', 'Business Rules', 'Client Scripts', 'ACLs'],
  },
  {
    label: 'Design & Marketing',
    skills: ['Canva', 'UI/UX Principles', 'Google Ads', 'Social Media'],
  },
  {
    label: 'Programming',
    skills: ['Python', 'Java', 'C++', 'SQL'],
  },
];

export default function Skills() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.1 });

  return (
    <section
      id="skills"
      ref={sectionRef}
      aria-labelledby="skills-heading"
      className="section"
      style={{ background: 'var(--surface)' }}
    >
      <div className="container-tight">
        <span className="section-label">Skills</span>
        <h2 id="skills-heading" className="section-title mt-3">
          Technologies I <em>know well</em>
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-10 lg:gap-16 mt-10 items-start">
          {/* Intro Text */}
          <p
            className={`text-[var(--text-secondary)] leading-relaxed pt-1 transition-all duration-700 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
            }`}
            style={{
              fontSize: '0.95rem',
              lineHeight: 1.8,
              maxWidth: '45ch',
              transitionTimingFunction: 'var(--ease-out-expo)',
            }}
          >
            I keep my stack focused and deep rather than wide and shallow. These are the tools I
            use daily on real client projects — not things I just listed on a resume.
          </p>

          {/* Skill Groups */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            {SKILL_GROUPS.map((group, gIdx) => (
              <div
                key={group.label}
                className={`transition-all duration-600 ${
                  isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
                }`}
                style={{
                  transitionTimingFunction: 'var(--ease-out-expo)',
                  transitionDelay: `${gIdx * 100}ms`,
                }}
              >
                <p
                  className="mb-4"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.68rem',
                    letterSpacing: '0.14em',
                    textTransform: 'uppercase',
                    color: 'var(--gold)',
                  }}
                >
                  {group.label}
                </p>
                <div className="flex flex-wrap gap-2">
                  {group.skills.map((skill) => (
                    <span key={skill} className="chip-item">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
