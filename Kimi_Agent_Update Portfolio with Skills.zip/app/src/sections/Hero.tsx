import { useRef, useEffect, useState } from 'react';
import { ArrowRight, Code2, Briefcase, Award } from 'lucide-react';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import ThreeScene from '@/components/ThreeScene';

/* ═══════════════════════════════════════════════════════════════════════════
   Hero — Full-viewport with 3D background
   Taste Skill: DESIGN_VARIANCE 8 — asymmetric, editorial layout
   Emil Design Eng: kinetic typography, sub-300ms reveals
   UI/UX Pro Max: no emojis, prefers-reduced-motion respected
   ═══════════════════════════════════════════════════════════════════════════ */

export default function Hero() {
  const reducedMotion = useReducedMotion();
  const [loaded, setLoaded] = useState(false);
  const nameRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLSpanElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  // Entrance animation — Emil Design Eng: staggered, sub-300ms
  useEffect(() => {
    if (reducedMotion) {
      setLoaded(true);
      return;
    }
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, [reducedMotion]);

  return (
    <section
      id="hero"
      aria-label="Hero section"
      className="relative min-h-[100dvh] grid place-items-center overflow-hidden"
      style={{ padding: '8rem 1.5rem 5rem' }}
    >
      {/* 3D Background */}
      <ThreeScene />

      {/* Content */}
      <div className="relative z-10 max-w-[900px] mx-auto text-center w-full">
        {/* Availability Pill — Lucide icons, no emojis */}
        <div
          className={`inline-flex items-center gap-2 rounded-full px-4 py-2 border mb-8 transition-all duration-500 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
          }`}
          style={{
            background: 'var(--gold-soft)',
            borderColor: 'oklch(72% 0.12 75 / 0.25)',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.7rem',
            color: 'var(--gold)',
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            transitionTimingFunction: 'var(--ease-out-expo)',
            transitionDelay: '100ms',
          }}
        >
          <span className="pulse-dot" aria-hidden="true" />
          Open to Freelance Projects
        </div>

        {/* Name — Kinetic Typography */}
        <h1
          ref={nameRef}
          className={`font-display font-extrabold text-[var(--text-primary)] leading-[1.02] tracking-[-0.04em] mb-2 transition-all duration-700 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2.8rem, 10vw, 7.5rem)',
            transitionTimingFunction: 'var(--ease-out-back)',
            transitionDelay: '200ms',
          }}
        >
          Daniyal Mahar
        </h1>

        {/* Subtitle Line */}
        <span
          ref={subtitleRef}
          className={`block text-[var(--gold)] font-display font-bold tracking-[-0.02em] transition-all duration-600 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(1.6rem, 5.5vw, 4rem)',
            transitionTimingFunction: 'var(--ease-out-expo)',
            transitionDelay: '350ms',
          }}
        >
          Web Developer.
        </span>

        {/* Subtext */}
        <p
          ref={textRef}
          className={`mx-auto mt-7 text-[var(--text-secondary)] leading-relaxed text-balanced transition-all duration-600 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{
            fontSize: 'clamp(0.9rem, 2vw, 1.1rem)',
            maxWidth: '560px',
            transitionTimingFunction: 'var(--ease-out-expo)',
            transitionDelay: '500ms',
          }}
        >
          I build fast, conversion-focused websites and enterprise-grade ServiceNow solutions
          for businesses that mean it. Based in Islamabad — working globally.
        </p>

        {/* CTAs */}
        <div
          ref={ctaRef}
          className={`flex items-center justify-center gap-4 flex-wrap mt-10 transition-all duration-500 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{
            transitionTimingFunction: 'var(--ease-out-expo)',
            transitionDelay: '600ms',
          }}
        >
          <a href="#contact" className="btn-primary">
            Start a Project
            <ArrowRight size={16} aria-hidden="true" />
            <span className="shimmer" aria-hidden="true" />
          </a>
          <a href="#services" className="btn-secondary">
            View My Services
          </a>
        </div>

        {/* Stats — DESIGN_VARIANCE 8: asymmetric dividers */}
        <div
          ref={statsRef}
          className={`flex items-center justify-center gap-6 md:gap-12 mt-16 pt-12 border-t border-[var(--border)] flex-wrap transition-all duration-600 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{
            transitionTimingFunction: 'var(--ease-out-expo)',
            transitionDelay: '700ms',
          }}
        >
          <StatItem icon={<Code2 size={18} />} value="2+" label="Years Experience" />
          <StatDivider />
          <StatItem icon={<Briefcase size={18} />} value="10+" label="Technologies" />
          <StatDivider />
          <StatItem icon={<Award size={18} />} value="100%" label="Client Satisfaction" />
        </div>
      </div>
    </section>
  );
}

/* ── Stat Item — Lucide icons, no emojis ────────────────────────────────── */
function StatItem({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-[var(--gold)] opacity-50" aria-hidden="true">
        {icon}
      </span>
      <div className="text-left">
        <div
          className="font-display font-extrabold text-[var(--text-primary)] leading-none"
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(1.6rem, 3.5vw, 2.4rem)',
          }}
        >
          {value}
        </div>
        <div
          className="font-mono text-[var(--text-muted)] mt-1 tracking-wide"
          style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}
        >
          {label}
        </div>
      </div>
    </div>
  );
}

function StatDivider() {
  return (
    <div
      className="hidden md:block w-px h-10 bg-[var(--border)]"
      aria-hidden="true"
    />
  );
}
