import { useRef, useState, type FormEvent } from 'react';
import { Mail, Phone, Linkedin, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   Contact — Two-column: info + form
   Impeccable: proper form labels, touch targets
   UI/UX Pro Max: accessible form, focus states, error handling
   Emil Design Eng: smooth form interactions
   ═══════════════════════════════════════════════════════════════════════════ */

const CONTACT_ITEMS = [
  {
    icon: <Mail size={16} />,
    label: 'daniyalmahar2001@gmail.com',
    href: 'mailto:daniyalmahar2001@gmail.com',
  },
  {
    icon: <Phone size={16} />,
    label: '+92 336 2485817',
    href: 'tel:+923362485817',
  },
  {
    icon: <Linkedin size={16} />,
    label: 'LinkedIn Profile',
    href: 'https://pk.linkedin.com/in/abdul-jabbar-alias-daniyal-mahar-0aba2025a',
    external: true,
  },
];

export default function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.1 });
  const [formState, setFormState] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormState('sending');

    try {
      const form = e.currentTarget;
      const res = await fetch('https://formspree.io/f/xgolkenv', {
        method: 'POST',
        body: new FormData(form),
        headers: { Accept: 'application/json' },
      });

      if (res.ok) {
        setFormState('success');
        form.reset();
        setTimeout(() => setFormState('idle'), 5000);
      } else {
        throw new Error('Request failed');
      }
    } catch {
      setFormState('error');
      setTimeout(() => setFormState('idle'), 4000);
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      aria-labelledby="contact-heading"
      className="section"
      style={{ background: 'var(--surface)' }}
    >
      <div className="container-tight">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left: Contact Info */}
          <div
            className={`transition-all duration-700 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
            }`}
            style={{ transitionTimingFunction: 'var(--ease-out-expo)' }}
          >
            <span className="section-label">Contact</span>
            <h2
              id="contact-heading"
              className="font-display font-bold text-[var(--text-primary)] tracking-[-0.02em] mt-3 mb-4 leading-tight"
              style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}
            >
              Let's make something
              <br />
              great together.
            </h2>
            <p className="text-[var(--text-muted)] mb-8 leading-relaxed" style={{ fontSize: '0.9rem' }}>
              Fill out the form or reach out directly. I'm currently available for freelance projects and will get back to you within 24 hours.
            </p>

            {/* Contact Items */}
            <div className="flex flex-col gap-3">
              {CONTACT_ITEMS.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  target={item.external ? '_blank' : undefined}
                  rel={item.external ? 'noopener noreferrer' : undefined}
                  className="flex items-center gap-3 text-sm text-[var(--text-secondary)] no-underline border border-[var(--border)] rounded-lg px-4 py-3 transition-all duration-150 hover:border-[var(--gold-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-2)]"
                  style={{
                    transitionTimingFunction: 'var(--ease-out-expo)',
                    minHeight: '48px',
                  }}
                >
                  <span
                    className="w-9 h-9 rounded-md grid place-items-center flex-shrink-0"
                    style={{ background: 'var(--surface-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}
                  >
                    <span className="text-[var(--gold)]">{item.icon}</span>
                  </span>
                  {item.label}
                </a>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div
            className={`transition-all duration-700 delay-100 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
            }`}
            style={{ transitionTimingFunction: 'var(--ease-out-expo)' }}
          >
            <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate aria-label="Contact form">
              {/* Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Your Name" name="name" type="text" placeholder="John Smith" required />
                <Field label="Email" name="email" type="email" placeholder="you@email.com" required />
              </div>

              {/* Service */}
              <div className="field">
                <label
                  htmlFor="service"
                  className="block mb-1"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.65rem',
                    letterSpacing: '0.14em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                  }}
                >
                  Service Needed
                </label>
                <select
                  id="service"
                  name="service"
                  className="w-full bg-[var(--surface-2)] border border-[var(--border)] text-[var(--text-primary)] px-4 py-3 rounded-lg font-body text-sm outline-none transition-colors duration-150 focus:border-[var(--gold-muted)]"
                  style={{
                    fontFamily: 'var(--font-body)',
                    appearance: 'none',
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right 12px center',
                    paddingRight: '40px',
                  }}
                >
                  <option value="" disabled selected>Select a service...</option>
                  <option>WordPress Website</option>
                  <option>ServiceNow Development</option>
                  <option>Landing Page / Web Design</option>
                  <option>Other</option>
                </select>
              </div>

              {/* Budget */}
              <div className="field">
                <label
                  htmlFor="budget"
                  className="block mb-1"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.65rem',
                    letterSpacing: '0.14em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                  }}
                >
                  Budget Range
                </label>
                <select
                  id="budget"
                  name="budget"
                  className="w-full bg-[var(--surface-2)] border border-[var(--border)] text-[var(--text-primary)] px-4 py-3 rounded-lg font-body text-sm outline-none transition-colors duration-150 focus:border-[var(--gold-muted)]"
                  style={{
                    fontFamily: 'var(--font-body)',
                    appearance: 'none',
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right 12px center',
                    paddingRight: '40px',
                  }}
                >
                  <option value="" disabled selected>Select your budget...</option>
                  <option>Under $500</option>
                  <option>$500 - $1,000</option>
                  <option>$1,000 - $3,000</option>
                  <option>$3,000+</option>
                </select>
              </div>

              {/* Message */}
              <div className="field">
                <label
                  htmlFor="message"
                  className="block mb-1"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.65rem',
                    letterSpacing: '0.14em',
                    textTransform: 'uppercase',
                    color: 'var(--text-muted)',
                  }}
                >
                  Project Details
                </label>
                <textarea
                  id="message"
                  name="message"
                  placeholder="Tell me about your project, goals, and timeline..."
                  required
                  rows={5}
                  className="w-full bg-[var(--surface-2)] border border-[var(--border)] text-[var(--text-primary)] px-4 py-3 rounded-lg font-body text-sm outline-none resize-none transition-colors duration-150 focus:border-[var(--gold-muted)] placeholder:text-[var(--text-subtle)]"
                  style={{ fontFamily: 'var(--font-body)', minHeight: '120px' }}
                />
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={formState === 'sending'}
                className="btn-primary w-full font-display font-bold"
                style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '0.95rem',
                  minHeight: '48px',
                  opacity: formState === 'sending' ? 0.65 : 1,
                }}
              >
                {formState === 'sending' ? (
                  <>
                    <span className="animate-spin inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full mr-2" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send size={16} />
                    Send Message
                  </>
                )}
              </button>

              {/* Success Message */}
              {formState === 'success' && (
                <div
                  role="status"
                  aria-live="polite"
                  className="flex items-center gap-2 rounded-lg px-4 py-3"
                  style={{
                    background: 'var(--green-soft)',
                    border: '1px solid var(--green-border)',
                    color: 'var(--green)',
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.83rem',
                    letterSpacing: '0.04em',
                  }}
                >
                  <CheckCircle size={16} />
                  Message sent! I'll reply within 24 hours.
                </div>
              )}

              {/* Error Message */}
              {formState === 'error' && (
                <div
                  role="alert"
                  aria-live="assertive"
                  className="flex items-center gap-2 rounded-lg px-4 py-3"
                  style={{
                    background: 'var(--red-soft)',
                    border: '1px solid var(--red-border)',
                    color: 'var(--red)',
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.83rem',
                    letterSpacing: '0.04em',
                  }}
                >
                  <AlertCircle size={16} />
                  Something went wrong. Please email me directly.
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Form Field Component ───────────────────────────────────────────────── */
function Field({
  label,
  name,
  type,
  placeholder,
  required = false,
}: {
  label: string;
  name: string;
  type: string;
  placeholder: string;
  required?: boolean;
}) {
  return (
    <div className="field">
      <label
        htmlFor={name}
        className="block mb-1"
        style={{
          fontFamily: 'var(--font-mono)',
          fontSize: '0.65rem',
          letterSpacing: '0.14em',
          textTransform: 'uppercase',
          color: 'var(--text-muted)',
        }}
      >
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        className="w-full bg-[var(--surface-2)] border border-[var(--border)] text-[var(--text-primary)] px-4 py-3 rounded-lg font-body text-sm outline-none transition-colors duration-150 focus:border-[var(--gold-muted)] placeholder:text-[var(--text-subtle)]"
        style={{ fontFamily: 'var(--font-body)' }}
      />
    </div>
  );
}
