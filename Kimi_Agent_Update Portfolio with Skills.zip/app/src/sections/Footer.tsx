/* ═══════════════════════════════════════════════════════════════════════════
   Footer — Clean, minimal
   Impeccable: proper spacing, clean hierarchy
   ═══════════════════════════════════════════════════════════════════════════ */

const FOOTER_LINKS = [
  { label: 'Email', href: 'mailto:daniyalmahar2001@gmail.com' },
  { label: 'LinkedIn', href: 'https://pk.linkedin.com/in/abdul-jabbar-alias-daniyal-mahar-0aba2025a', external: true },
  { label: 'Portfolio', href: 'https://abduljabbarmahar.github.io/Daniyal-Mahar/', external: true },
];

export default function Footer() {
  return (
    <footer
      role="contentinfo"
      className="border-t border-[var(--border)] px-6 py-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-4"
      style={{ background: 'var(--base)' }}
    >
      {/* Logo */}
      <a
        href="#"
        className="font-display font-extrabold text-[var(--text-primary)] no-underline tracking-tight"
        style={{ fontFamily: 'var(--font-display)', fontSize: '1rem' }}
      >
        dm<em className="text-[var(--gold)] not-italic">.</em>
      </a>

      {/* Copyright */}
      <p
        className="text-[var(--text-muted)] order-3 md:order-2"
        style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem' }}
      >
        &copy; {new Date().getFullYear()} Daniyal Mahar. All rights reserved.
      </p>

      {/* Links */}
      <ul
        className="flex gap-6 list-none m-0 p-0 order-2 md:order-3"
        aria-label="Footer navigation"
      >
        {FOOTER_LINKS.map((link) => (
          <li key={link.href}>
            <a
              href={link.href}
              target={link.external ? '_blank' : undefined}
              rel={link.external ? 'noopener noreferrer' : undefined}
              className="text-[var(--text-muted)] no-underline transition-colors duration-150 hover:text-[var(--gold)]"
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.8rem',
                transitionTimingFunction: 'var(--ease-out-expo)',
              }}
            >
              {link.label}
            </a>
          </li>
        ))}
      </ul>
    </footer>
  );
}
