import { useRef } from 'react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   Experience — Editorial list layout
   Taste Skill: DESIGN_VARIANCE 8 — offset date column
   Impeccable: clean hierarchy, proper spacing
   ═══════════════════════════════════════════════════════════════════════════ */

const EXPERIENCES = [
  {
    date: 'Jun 2025 — Present',
    company: 'Prof. College of Nursing',
    role: 'IT Manager & Web Developer',
    desc: "Manage and develop the institution's WordPress website, oversee all digital presence including social media campaigns, and handle full IT support. Design digital content using Canva and deliver lectures on MS Office and digital literacy.",
    tags: ['WordPress', 'Canva', 'IT Support', 'Social Media'],
  },
  {
    date: 'Aug 2024 — Aug 2025',
    company: 'Innovise',
    role: 'Technical Consultant — ServiceNow',
    desc: 'Delivered enterprise-grade ServiceNow solutions across ITSM, HRSD, ITOM, CMDB, and Custom App Development. Designed catalog items, workflows, and automation using Flow Designer, Business Rules, UI Policies, Notifications, and ACLs. Built HR offboarding flows, role-based access, and dashboards.',
    tags: ['ITSM', 'HRSD', 'ITOM', 'CMDB', 'Flow Designer', 'GlideRecord'],
  },
  {
    date: 'May 2024 — Present',
    company: 'Freelance / Remote',
    role: 'ServiceNow Developer',
    desc: 'Independent ServiceNow development for remote clients — building custom workflows, Service Catalog items, Business Rules, UI Policies, and Client Scripts. Managed ACLs, scheduled jobs, and notification templates.',
    tags: ['Freelance', 'Business Rules', 'Client Scripts', 'Catalog Items'],
  },
  {
    date: 'Feb 2024 — Apr 2024',
    company: 'Motiventive',
    role: 'Business Development Executive',
    desc: 'Identified and bid on projects via Upwork and Freelancer.com. Engaged clients to understand their needs, built trust through communication, and secured new business. Focused on client acquisition, relationship management, and pipeline growth.',
    tags: ['Business Dev', 'Upwork', 'Client Relations'],
  },
];

export default function Experience() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.1 });

  return (
    <section
      id="experience"
      ref={sectionRef}
      aria-labelledby="exp-heading"
      className="section"
    >
      <div className="container-tight">
        <span className="section-label">Experience</span>
        <h2 id="exp-heading" className="section-title mt-3">
          Where I've <em>done the work</em>
        </h2>

        <div className="mt-12" role="list">
          {EXPERIENCES.map((exp, idx) => (
            <div
              key={exp.role}
              role="listitem"
              className={`grid grid-cols-1 md:grid-cols-[200px_1fr] gap-4 md:gap-12 py-8 border-b border-[var(--border)] first:pt-0 last:border-b-0 last:pb-0 transition-all duration-700 ${
                isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
              }`}
              style={{
                transitionTimingFunction: 'var(--ease-out-expo)',
                transitionDelay: `${idx * 100}ms`,
              }}
            >
              {/* Left: Date & Company */}
              <div>
                <p
                  className="text-[var(--text-muted)] mb-2"
                  style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', letterSpacing: '0.04em' }}
                >
                  {exp.date}
                </p>
                <p
                  className="text-[var(--gold)] font-medium"
                  style={{ fontSize: '0.82rem' }}
                >
                  {exp.company}
                </p>
              </div>

              {/* Right: Role & Description */}
              <div>
                <h3
                  className="font-display font-bold text-[var(--text-primary)] mb-3 leading-tight tracking-[-0.02em]"
                  style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem' }}
                >
                  {exp.role}
                </h3>
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                  {exp.desc}
                </p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {exp.tags.map((tag) => (
                    <span key={tag} className="tag">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
