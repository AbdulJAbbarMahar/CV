import { useRef } from 'react';
import { GraduationCap, Award } from 'lucide-react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   Education — Single card with credentials
   UI/UX Pro Max: Lucide icons, proper structure
   ═══════════════════════════════════════════════════════════════════════════ */

const CERTS = [
  'Web Software & Mobile Web Development',
  'Introduction to Internet of Things',
];

export default function Education() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.15 });

  return (
    <section
      id="education"
      ref={sectionRef}
      aria-labelledby="edu-heading"
      className="section"
      style={{ background: 'var(--surface)' }}
    >
      <div className="container-tight">
        <span className="section-label">Education</span>
        <h2 id="edu-heading" className="section-title mt-3">
          Where it all <em>started</em>
        </h2>

        <div
          className={`bento-card p-8 md:p-10 mt-12 flex flex-col sm:flex-row items-start gap-6 md:gap-8 transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-5 scale-[0.97]'
          }`}
          style={{ transitionTimingFunction: 'var(--ease-out-back)' }}
        >
          {/* Icon */}
          <div
            className="flex-shrink-0 w-14 h-14 rounded-xl grid place-items-center"
            style={{
              background: 'var(--gold-soft)',
              border: '1px solid var(--gold-muted)',
            }}
          >
            <GraduationCap size={28} className="text-[var(--gold)]" aria-hidden="true" />
          </div>

          {/* Content */}
          <div className="flex-1">
            <h3
              className="font-display font-bold text-[var(--text-primary)] tracking-[-0.02em]"
              style={{ fontFamily: 'var(--font-display)', fontSize: '1.15rem', marginBottom: '0.35rem' }}
            >
              Bachelor of Engineering — Computer Systems Engineering
            </h3>
            <p className="text-[var(--gold)] font-medium mb-1" style={{ fontSize: '0.9rem' }}>
              Mehran University of Engineering and Technology
            </p>
            <p
              className="text-[var(--text-muted)] mb-4"
              style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', letterSpacing: '0.04em' }}
            >
              Oct 2019 — Nov 2023
            </p>
            <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
              Studied computer systems engineering with a focus on software development, networks, and digital systems. Built a strong foundation in algorithms, data structures, and systems programming that underpins everything I build today.
            </p>

            {/* Certificates */}
            <div className="flex gap-3 mt-5 flex-wrap">
              {CERTS.map((cert) => (
                <span
                  key={cert}
                  className="inline-flex items-center gap-1.5 font-mono rounded-full px-3 py-1.5 border"
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.68rem',
                    letterSpacing: '0.04em',
                    color: 'var(--gold)',
                    background: 'var(--gold-soft)',
                    borderColor: 'var(--gold-muted)',
                  }}
                >
                  <Award size={12} />
                  {cert}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
