import { useRef } from 'react';
import { Star, ExternalLink, Mountain, Building2, Settings, Zap } from 'lucide-react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   Projects — Asymmetric Bento Grid
   Taste Skill: DESIGN_VARIANCE 8 — featured card spans full width
   Impeccable: proper contrast, no AI-slop card-within-card
   UI/UX Pro Max: Lucide icons, touch targets 44px+
   Emil Design Eng: smooth hover states, spring easing
   ═══════════════════════════════════════════════════════════════════════════ */

const PROJECTS = [
  {
    featured: true,
    icon: <Mountain size={56} />,
    badge: 'Featured',
    category: 'Web Design & Development · Tourism',
    title: 'KarakoramTrails — Pakistan Travel Agency',
    desc: 'A complete, multi-page travel agency website for northern Pakistan tourism — pure HTML, CSS, and vanilla JavaScript. Features 6 fully functional pages, animated particle hero, dynamic tour filtering, real-time price calculator with group discounts, full form validation, tour detail modals with day-by-day itineraries, and a booking confirmation overlay. Deployed on GitHub Pages.',
    tags: ['HTML / CSS / JS', 'Multi-Page SPA', 'Animations', 'Form Validation', 'Responsive', 'Zero Dependencies', 'GitHub Pages'],
    href: 'https://abduljabbarmahar.github.io/travel-website/',
  },
  {
    featured: false,
    icon: <Building2 size={40} />,
    category: 'WordPress · Healthcare',
    title: 'Nursing College Website',
    desc: 'Designed, developed, and maintain the official website for Professional College of Nursing & Allied Health Sciences Islamabad — admissions, announcements, faculty, and digital presence.',
    tags: ['WordPress', 'Canva', 'Social Media'],
  },
  {
    featured: false,
    icon: <Settings size={40} />,
    category: 'ServiceNow · Enterprise',
    title: 'HR Offboarding Automation',
    desc: 'Built a complete HR offboarding flow in ServiceNow HRSD — multi-level approvals, automated task assignment, role-based access revocation, and real-time dashboards.',
    tags: ['HRSD', 'Flow Designer', 'GlideRecord', 'ACLs'],
  },
  {
    featured: false,
    icon: <Zap size={40} />,
    category: 'Web Design · Freelance',
    title: 'Conversion Landing Pages',
    desc: 'Hand-coded performance landing pages for freelance clients — zero dependencies, sub-2s load times, fully responsive, deployed on GitHub Pages. Focused on clarity and conversion.',
    tags: ['HTML/CSS/JS', 'GitHub Pages', 'Performance'],
  },
];

export default function Projects() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.08 });

  return (
    <section
      id="projects"
      ref={sectionRef}
      aria-labelledby="projects-heading"
      className="section"
    >
      <div className="container-tight">
        {/* Header */}
        <div
          className={`transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
          }`}
          style={{ transitionTimingFunction: 'var(--ease-out-expo)' }}
        >
          <span className="section-label">Selected Work</span>
          <h2 id="projects-heading" className="section-title mt-3">
            Projects I've <em>shipped</em>
          </h2>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-12">
          {PROJECTS.map((project, idx) => (
            <ProjectCard
              key={project.title}
              project={project}
              idx={idx}
              isInView={isInView}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Project Card ───────────────────────────────────────────────────────── */
function ProjectCard({
  project,
  idx,
  isInView,
}: {
  project: (typeof PROJECTS)[0];
  idx: number;
  isInView: boolean;
}) {
  const cardRef = useRef<HTMLDivElement>(null);

  return (
    <div
      ref={cardRef}
      className={`bento-card flex flex-col transition-all duration-700 ${
        project.featured ? 'md:col-span-2 md:flex-row md:min-h-[360px]' : ''
      } ${isInView ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-5 scale-[0.97]'}`}
      style={{
        transitionTimingFunction: 'var(--ease-out-back)',
        transitionDelay: `${idx * 80}ms`,
      }}
    >
      {/* Thumbnail */}
      <div
        className={`relative flex items-center justify-center flex-shrink-0 overflow-hidden ${
          project.featured
            ? 'md:w-[320px] w-full h-[180px] md:h-auto'
            : 'w-full h-[160px]'
        }`}
        style={{
          background: 'linear-gradient(135deg, oklch(13% 0.02 75) 0%, oklch(11% 0.01 285) 100%)',
        }}
      >
        {/* Glow */}
        <div
          className="absolute w-[200px] h-[200px] rounded-full pointer-events-none"
          style={{
            background: 'radial-gradient(circle, oklch(72% 0.12 75 / 0.12) 0%, transparent 70%)',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
          }}
          aria-hidden="true"
        />

        {/* Featured Badge */}
        {project.featured && (
          <span
            className="absolute top-4 left-4 inline-flex items-center gap-1.5 rounded-full px-3 py-1 border z-10"
            style={{
              background: 'var(--gold-soft)',
              borderColor: 'var(--gold-muted)',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.65rem',
              color: 'var(--gold)',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
            }}
          >
            <Star size={10} />
            Featured
          </span>
        )}

        {/* Icon */}
        <span
          className="relative z-[1]"
          style={{ color: 'var(--gold)', opacity: 0.7 }}
          aria-hidden="true"
        >
          {project.icon}
        </span>
      </div>

      {/* Body */}
      <div className="flex flex-col gap-3 p-6 md:p-8 flex-1 relative z-[2]">
        <p
          className="font-mono uppercase tracking-wider"
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '0.68rem',
            color: 'var(--gold)',
            letterSpacing: '0.08em',
          }}
        >
          {project.category}
        </p>

        <h3
          className="font-display font-bold text-[var(--text-primary)] leading-tight tracking-[-0.02em]"
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: project.featured ? '1.4rem' : '1.05rem',
          }}
        >
          {project.title}
        </h3>

        <p className="text-sm text-[var(--text-secondary)] leading-relaxed flex-1">
          {project.desc}
        </p>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mt-2">
          {project.tags.map((tag) => (
            <span key={tag} className="tag">
              {tag}
            </span>
          ))}
        </div>

        {/* Live Link */}
        {project.href && (
          <a
            href={project.href}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-3 font-mono uppercase rounded-md px-4 py-2 border w-fit transition-all duration-150 hover:bg-[var(--gold-glow)] hover:border-[var(--gold-muted)]"
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.72rem',
              letterSpacing: '0.06em',
              color: 'var(--gold)',
              background: 'var(--gold-soft)',
              borderColor: 'var(--gold-muted)',
              minHeight: '44px',
              transitionTimingFunction: 'var(--ease-out-expo)',
            }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full flex-shrink-0"
              style={{ background: 'var(--green)' }}
              aria-hidden="true"
            />
            View Live Demo
            <ExternalLink size={12} />
          </a>
        )}
      </div>
    </div>
  );
}
