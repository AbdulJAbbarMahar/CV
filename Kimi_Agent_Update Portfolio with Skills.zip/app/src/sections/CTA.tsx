import { useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   CTA Banner — Centered call-to-action box
   Taste Skill: VISUAL_DENSITY 4 — generous whitespace
   Emil Design Eng: glow effect, smooth hover
   ═══════════════════════════════════════════════════════════════════════════ */

export default function CTA() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.3 });

  return (
    <section
      id="cta-banner"
      ref={sectionRef}
      aria-label="Call to action"
      className="py-20 md:py-24 px-6"
    >
      <div className="container-tight">
        <div
          className={`relative text-center rounded-2xl border p-10 md:p-16 overflow-hidden transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-5 scale-[0.97]'
          }`}
          style={{
            background: 'var(--surface)',
            borderColor: 'var(--border)',
            transitionTimingFunction: 'var(--ease-out-back)',
          }}
        >
          {/* Glow */}
          <div
            className="absolute pointer-events-none"
            style={{
              top: '-100px',
              left: '50%',
              transform: 'translateX(-50%)',
              width: '400px',
              height: '300px',
              background: 'radial-gradient(circle, oklch(72% 0.12 75 / 0.1) 0%, transparent 70%)',
            }}
            aria-hidden="true"
          />

          {/* Content */}
          <h2
            className="relative z-[1] font-display font-extrabold text-[var(--text-primary)] tracking-[-0.03em] mb-4"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(1.6rem, 4vw, 2.8rem)',
              lineHeight: 1.15,
            }}
          >
            Have a project in mind?
            <br />
            Let's <em className="text-[var(--gold)] not-italic">build it together.</em>
          </h2>

          <p className="relative z-[1] text-[var(--text-muted)] mb-8 leading-relaxed" style={{ fontSize: '0.95rem' }}>
            Whether it's a WordPress site, a landing page, or a ServiceNow workflow —
            <br className="hidden sm:block" />
            I'm ready to start. Response within 24 hours, always.
          </p>

          <a href="#contact" className="btn-primary relative z-[1] inline-flex">
            Get in Touch
            <ArrowRight size={16} />
            <span className="shimmer" aria-hidden="true" />
          </a>
        </div>
      </div>
    </section>
  );
}
