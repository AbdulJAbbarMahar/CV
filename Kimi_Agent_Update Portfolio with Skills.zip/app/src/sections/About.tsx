import { useRef } from 'react';
import { Mail, Linkedin, Globe, ExternalLink } from 'lucide-react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   About — Two-column editorial layout
   Taste Skill: DESIGN_VARIANCE 8 — asymmetric grid (1fr 1.2fr)
   Impeccable: readable line lengths (max 65ch), vertical rhythm
   UI/UX Pro Max: Lucide icons, proper contrast
   ═══════════════════════════════════════════════════════════════════════════ */

const TECH_STACK = [
  { icon: <Globe size={16} />, label: 'WordPress' },
  { icon: <ExternalLink size={16} />, label: 'JavaScript' },
  { icon: <CodeIcon size={16} />, label: 'HTML & CSS' },
  { icon: <SettingsIcon size={16} />, label: 'ServiceNow' },
  { icon: <FlowIcon size={16} />, label: 'Flow Designer' },
  { icon: <ResponsiveIcon size={16} />, label: 'Responsive Design' },
  { icon: <PaletteIcon size={16} />, label: 'Canva & Design' },
  { icon: <TrendingIcon size={16} />, label: 'Google Ads' },
];

const SOCIAL_LINKS = [
  { icon: <Mail size={15} />, label: 'Email Me', href: 'mailto:daniyalmahar2001@gmail.com' },
  { icon: <Linkedin size={15} />, label: 'LinkedIn', href: 'https://pk.linkedin.com/in/abdul-jabbar-alias-daniyal-mahar-0aba2025a', external: true },
  { icon: <Globe size={15} />, label: 'Portfolio', href: 'https://abduljabbarmahar.github.io/Daniyal-Mahar/', external: true },
];

export default function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.15 });

  return (
    <section
      id="about"
      ref={sectionRef}
      aria-labelledby="about-heading"
      className="section"
      style={{ background: 'var(--surface)' }}
    >
      <div className="container-tight">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.2fr] gap-12 lg:gap-20 items-center">
          {/* Left Column — Bio */}
          <div
            className={`transition-all duration-700 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-9'
            }`}
            style={{
              transitionTimingFunction: 'var(--ease-out-expo)',
            }}
          >
            <span className="section-label">About Me</span>
            <h2
              id="about-heading"
              className="section-title mt-3"
              style={{ marginTop: '0.75rem' }}
            >
              Building digital things
              <br />
              that <em>actually work.</em>
            </h2>

            <p
              className="mt-6 text-[var(--text-secondary)] leading-[1.85]"
              style={{ fontSize: '0.97rem', maxWidth: '55ch' }}
            >
              I'm a <strong className="text-[var(--text-primary)] font-medium">freelance web developer and ServiceNow consultant</strong> based in
              Islamabad, Pakistan. With a background in Computer Systems Engineering and hands-on
              experience across real client projects, I bridge the gap between clean code and real
              business outcomes.
            </p>

            <p
              className="mt-4 text-[var(--text-secondary)] leading-[1.85]"
              style={{ fontSize: '0.97rem', maxWidth: '55ch' }}
            >
              I currently manage and develop the WordPress presence for a healthcare institution
              while taking on freelance projects remotely. I'm direct, deadline-driven, and I write
              code that people can actually maintain.
            </p>

            {/* Social Links */}
            <div className="flex gap-3 mt-8 flex-wrap">
              {SOCIAL_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  target={link.external ? '_blank' : undefined}
                  rel={link.external ? 'noopener noreferrer' : undefined}
                  className="inline-flex items-center gap-2 text-sm text-[var(--text-secondary)] no-underline border border-[var(--border)] px-4 py-2 rounded-md transition-all duration-150 hover:border-[var(--gold)] hover:text-[var(--gold)]"
                  style={{ transitionTimingFunction: 'var(--ease-out-expo)' }}
                >
                  {link.icon}
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Right Column — Tech Stack */}
          <div
            className={`transition-all duration-700 delay-100 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-9'
            }`}
            style={{ transitionTimingFunction: 'var(--ease-out-expo)' }}
          >
            <span className="section-label">My Stack</span>
            <div
              className="grid grid-cols-2 gap-3 mt-4"
              style={{ marginTop: '1.5rem' }}
            >
              {TECH_STACK.map((tech) => (
                <div
                  key={tech.label}
                  className="flex items-center gap-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-lg px-4 py-3 text-sm text-[var(--text-primary)] transition-all duration-150 hover:border-[var(--gold-muted)] hover:-translate-y-[3px]"
                  style={{
                    transitionTimingFunction: 'var(--ease-out-expo)',
                    fontSize: '0.87rem',
                  }}
                >
                  <span className="text-[var(--gold)]" aria-hidden="true">
                    {tech.icon}
                  </span>
                  {tech.label}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Simple SVG Icons (Lucide alternatives for inline use) ──────────────── */
function CodeIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="16 18 22 12 16 6" /><polyline points="8 6 2 12 8 18" />
    </svg>
  );
}

function SettingsIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function FlowIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242" /><path d="M12 12v9" /><path d="m16 16-4-4-4 4" />
    </svg>
  );
}

function ResponsiveIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect width="18" height="18" x="3" y="3" rx="2" /><path d="M3 9h18" /><path d="M9 21V9" />
    </svg>
  );
}

function PaletteIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" /><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" /><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" /><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" /><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" />
    </svg>
  );
}

function TrendingIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" /><polyline points="16 7 22 7 22 13" />
    </svg>
  );
}
