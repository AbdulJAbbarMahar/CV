import { useRef } from 'react';
import { ArrowRight, Globe, Cog, Zap, Search, Code2, ListChecks } from 'lucide-react';
import { useInView } from '@/hooks/useInView';

/* ═══════════════════════════════════════════════════════════════════════════
   Services — 3-column bento grid + 4-step process
   Taste Skill: DESIGN_VARIANCE 8 — staggered cards, asymmetric offsets
   Emil Design Eng: hover under 300ms, spring easing
   UI/UX Pro Max: Lucide icons, no emojis, proper labels
   ═══════════════════════════════════════════════════════════════════════════ */

const SERVICES = [
  {
    num: '01',
    icon: <Globe size={28} />,
    title: 'WordPress Development',
    desc: 'Fast, secure, and fully custom WordPress websites built for real business goals — not just aesthetics. From concept to deployment.',
    tags: ['WordPress', 'WooCommerce', 'Custom Themes', 'Performance', 'SEO'],
  },
  {
    num: '02',
    icon: <Cog size={28} />,
    title: 'ServiceNow Development',
    desc: 'Enterprise automation, catalog design, and custom app development. ITSM, HRSD, ITOM — built properly with clean scripting.',
    tags: ['ITSM', 'HRSD', 'Flow Designer', 'GlideScript', 'ACLs'],
  },
  {
    num: '03',
    icon: <Zap size={28} />,
    title: 'Landing Pages & Web Design',
    desc: 'Hand-coded performance landing pages. Zero bloat, sub-2s load times, pixel-perfect on every device.',
    tags: ['HTML/CSS/JS', 'Conversion', 'Responsive', 'GitHub Pages'],
  },
];

const PROCESS_STEPS = [
  {
    num: '01',
    icon: <Search size={20} />,
    title: 'Discovery Call',
    desc: "We talk through your goals, constraints, and timeline. No jargon, no pressure — just a direct conversation about what you need.",
  },
  {
    num: '02',
    icon: <ListChecks size={20} />,
    title: 'Scope & Quote',
    desc: 'You get a clear scope of work, timeline, and fixed price. No hidden fees, no scope creep surprises — everything in writing.',
  },
  {
    num: '03',
    icon: <Code2 size={20} />,
    title: 'Build & Review',
    desc: 'I build iteratively with regular check-ins. You see progress early and can give feedback before anything is final.',
  },
  {
    num: '04',
    icon: <RocketIcon size={20} />,
    title: 'Launch & Support',
    desc: "Clean handover with documentation. I'm available post-launch — you're never left alone after delivery.",
  },
];

export default function Services() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.1 });

  return (
    <section
      id="services"
      ref={sectionRef}
      aria-labelledby="services-heading"
      className="section"
    >
      <div className="container-tight">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-12">
          <div>
            <span className="section-label">What I Do</span>
            <h2 id="services-heading" className="section-title mt-3">
              Services I <em>offer</em>
            </h2>
          </div>
          <a href="#contact" className="btn-secondary">
            Get a Quote
            <ArrowRight size={16} />
          </a>
        </div>

        {/* Services Grid — 3-column bento */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((service, idx) => (
            <div
              key={service.num}
              className={`bento-card p-8 md:p-10 transition-all duration-700 ${
                isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
              }`}
              style={{
                transitionTimingFunction: 'var(--ease-out-expo)',
                transitionDelay: `${idx * 100}ms`,
              }}
            >
              {/* Service Number */}
              <div
                className="flex items-center gap-2 mb-7"
                style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--gold)', letterSpacing: '0.1em' }}
              >
                <span>{service.num}</span>
                <span className="flex-1 h-px bg-[var(--border)] max-w-[40px]" />
              </div>

              {/* Icon — Lucide, no emoji */}
              <span className="block text-[var(--gold)] mb-5" aria-hidden="true">
                {service.icon}
              </span>

              <h3
                className="font-display font-bold text-[var(--text-primary)] mb-3 tracking-[-0.02em]"
                style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem' }}
              >
                {service.title}
              </h3>

              <p className="text-sm text-[var(--text-muted)] leading-relaxed mb-6">
                {service.desc}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                {service.tags.map((tag) => (
                  <span key={tag} className="tag">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Process Steps — 4-column with stagger */}
        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-16 pt-16 border-t border-[var(--border)]"
          role="list"
          aria-label="Work process"
        >
          {PROCESS_STEPS.map((step, idx) => (
            <div
              key={step.num}
              role="listitem"
              className={`transition-all duration-600 ${
                isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-7'
              }`}
              style={{
                transitionTimingFunction: 'var(--ease-out-expo)',
                transitionDelay: `${300 + idx * 100}ms`,
              }}
            >
              <div className="flex items-center gap-2 mb-3">
                <span
                  className="text-[var(--gold)]"
                  style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.12em' }}
                >
                  {step.num}
                </span>
                <span className="text-[var(--gold)]" aria-hidden="true">{step.icon}</span>
              </div>
              <h4
                className="font-display font-bold text-[var(--text-primary)] mb-2 tracking-[-0.01em]"
                style={{ fontFamily: 'var(--font-display)', fontSize: '1.05rem' }}
              >
                {step.title}
              </h4>
              <p className="text-sm text-[var(--text-muted)] leading-relaxed">
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Inline SVG icon for Launch/Rocket ──────────────────────────────────── */
function RocketIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
      <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" />
      <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" />
      <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
    </svg>
  );
}
