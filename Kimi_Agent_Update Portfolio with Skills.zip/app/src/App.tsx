import { useEffect, useState, useRef } from 'react';
import { ArrowUp } from 'lucide-react';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import { useScrollProgress } from '@/hooks/useScrollProgress';
import { cn } from '@/lib/utils';
import Navbar from '@/components/Navbar';
import Hero from '@/sections/Hero';
import About from '@/sections/About';
import Services from '@/sections/Services';
import Projects from '@/sections/Projects';
import Skills from '@/sections/Skills';
import Experience from '@/sections/Experience';
import Education from '@/sections/Education';
import CTA from '@/sections/CTA';
import Contact from '@/sections/Contact';
import Footer from '@/sections/Footer';

/* ═══════════════════════════════════════════════════════════════════════════
   App — Root Component
   All sections composed with 4-skill design system:
   - UI/UX Pro Max: accessibility, responsive, no emojis
   - Emil Design Eng: custom easing, sub-300ms, perceived performance
   - Impeccable: anti-slop, proper typography, spatial design
   - Taste Skill: DESIGN_VARIANCE 8, MOTION_INTENSITY 6, VISUAL_DENSITY 4
   ═══════════════════════════════════════════════════════════════════════════ */

export default function App() {
  const reducedMotion = useReducedMotion();
  const progress = useScrollProgress();
  const [showScrollTop, setShowScrollTop] = useState(false);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  const cursorRingRef = useRef<HTMLDivElement>(null);
  const mousePos = useRef({ x: 0, y: 0 });
  const ringPos = useRef({ x: 0, y: 0 });
  const rafRef = useRef<number | undefined>(undefined);
  const isHovering = useRef(false);

  // Show scroll-to-top button
  useEffect(() => {
    setShowScrollTop(progress > 0.15);
  }, [progress]);

  // Custom cursor (fine pointer devices only)
  useEffect(() => {
    if (reducedMotion || !window.matchMedia('(pointer: fine)').matches) return;

    const dot = cursorDotRef.current;
    const ring = cursorRingRef.current;
    if (!dot || !ring) return;

    document.body.classList.add('custom-cursor-active');

    const onMouseMove = (e: MouseEvent) => {
      mousePos.current = { x: e.clientX, y: e.clientY };
      // Dot follows instantly
      dot.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%, -50%)`;
    };

    const onMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.closest('a, button, [role="button"], .bento-card, .chip-item, input, textarea, select')
      ) {
        if (!isHovering.current) {
          isHovering.current = true;
          dot.style.width = '14px';
          dot.style.height = '14px';
          ring.style.width = '48px';
          ring.style.height = '48px';
          ring.style.borderColor = 'var(--gold)';
        }
      } else {
        if (isHovering.current) {
          isHovering.current = false;
          dot.style.width = '8px';
          dot.style.height = '8px';
          ring.style.width = '32px';
          ring.style.height = '32px';
          ring.style.borderColor = 'oklch(72% 0.12 75 / 0.5)';
        }
      }
    };

    // Ring follows with lerp (Emil Design Eng: smooth interpolation)
    const animate = () => {
      const lerp = 0.12;
      ringPos.current.x += (mousePos.current.x - ringPos.current.x) * lerp;
      ringPos.current.y += (mousePos.current.y - ringPos.current.y) * lerp;
      ring.style.transform = `translate(${ringPos.current.x}px, ${ringPos.current.y}px) translate(-50%, -50%)`;
      rafRef.current = requestAnimationFrame(animate);
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mouseover', onMouseOver, { passive: true });
    rafRef.current = requestAnimationFrame(animate);

    return () => {
      document.body.classList.remove('custom-cursor-active');
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseover', onMouseOver);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [reducedMotion]);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  };

  return (
    <div className="relative min-h-[100dvh]">
      {/* Noise Texture Overlay (Taste Skill: premium feel) */}
      <div className="noise-overlay" aria-hidden="true" />

      {/* Custom Cursor */}
      {!reducedMotion && (
        <>
          <div
            ref={cursorDotRef}
            aria-hidden="true"
            className="fixed top-0 left-0 w-2 h-2 rounded-full pointer-events-none z-[9999] hidden md:block"
            style={{
              background: 'var(--gold)',
              transition: 'width 150ms var(--ease-out-expo), height 150ms var(--ease-out-expo)',
              willChange: 'transform',
            }}
          />
          <div
            ref={cursorRingRef}
            aria-hidden="true"
            className="fixed top-0 left-0 w-8 h-8 rounded-full pointer-events-none z-[9998] hidden md:block"
            style={{
              border: '1.5px solid oklch(72% 0.12 75 / 0.5)',
              transition: 'width 150ms var(--ease-out-expo), height 150ms var(--ease-out-expo), border-color 150ms var(--ease-out-expo)',
              willChange: 'transform',
            }}
          />
        </>
      )}

      {/* Scroll Progress Bar */}
      <div
        className="scroll-progress"
        aria-hidden="true"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(progress * 100)}
        style={{ transform: `scaleX(${progress})` }}
      />

      {/* Navigation */}
      <Navbar />

      {/* Main Content */}
      <main>
        <Hero />
        <About />
        <Services />
        <Projects />
        <Skills />
        <Experience />
        <Education />
        <CTA />
        <Contact />
      </main>

      {/* Footer */}
      <Footer />

      {/* Scroll to Top */}
      <button
        onClick={scrollToTop}
        aria-label="Scroll to top"
        className={cn(
          'fixed bottom-6 right-6 z-[700] w-11 h-11 rounded-lg grid place-items-center',
          'border transition-all duration-300',
          showScrollTop
            ? 'opacity-100 translate-y-0 pointer-events-auto'
            : 'opacity-0 translate-y-3 pointer-events-none'
        )}
        style={{
          background: 'var(--surface)',
          borderColor: 'var(--border)',
          color: 'var(--gold)',
          transitionTimingFunction: 'var(--ease-out-expo)',
        }}
      >
        <ArrowUp size={18} />
      </button>
    </div>
  );
}
